import os
import discord
from discord.ext import commands

prefix = '*'

client = commands.Bot(command_prefix=prefix)

client.remove_command("help")

for filename in os.listdir('Fast_echter_Spieler/commands'):
    if filename.endswith('.py'):
        client.load_extension(f'commands.{filename[:-3]}')

client.load_extension('events')


client.run(str: token)

