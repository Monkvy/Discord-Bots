from subprocess import Popen
import threading
import sys

def Loop():
    while True:
        pass

loopTask = threading.Thread(target=Loop)
loopTask.start()

Popen('python Among_Us/main.py')
Popen('python Fast_echter_Spieler/main.py') 
