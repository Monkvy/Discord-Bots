import discord
import random
from discord.ext import commands

class Default(commands.Cog):

    def __init__(self, client):
        self.client = client

    @commands.command(aliases=['Help', 'HELP'])
    async def help(self, ctx):
        author = ctx.message.author

        helpEmbed = discord.Embed(
            title = 'Hilfe  :mailbox_closed:',
            description = '**:joystick:   Hier werden alle Commands aufgelistet.  :joystick:**',
            colour = discord.Colour.green()
        )
        helpEmbed.add_field(name='Commands für alle:', 
            value='\n``.help``   Zeigt diese Nachrricht.\n' + 
                    '``.randomVote <zahl>``   Wählt eine zufällige Zahl aus', 
                    inline=False)

        helpEmbed.add_field(name='Commands für admins:', 
            value='\n``.muteAll``   Muted alle im Channel.\n' + 
                    '``.unMuteAll``   Unmuted alle im Channel.', 
                    inline=False)

        await ctx.channel.purge(limit=1)
        await author.send(embed=helpEmbed)
    
    @commands.command(aliases=['RANDOMVOTE', 'randomvote', 'Randomvote'])
    async def randomVote(self, ctx, nums):
        num = random.randint(1, int(nums))

        randomEmbed = discord.Embed(
            title = 'Random-Voting',
            description = f'Der Spieler {num} ist Ded',
            colour = discord.Colour.blue()
        )

        await ctx.channel.purge(limit=1)
        await ctx.send(embed=randomEmbed)


def setup(client):
    client.add_cog(Default(client))
    