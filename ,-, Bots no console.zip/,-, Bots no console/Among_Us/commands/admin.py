import discord
from discord.ext import commands

class BaseOwner(commands.Cog):

    def __init__(self, client):
        self.client = client

    @commands.command(aliases=['MuteAll', 'muteall', 'MUTEALL'])
    @commands.has_guild_permissions(administrator=True)
    async def muteAll(self, ctx):
        vc = ctx.author.voice.channel

        for member in vc.members:
            await member.edit(mute=True)

        await ctx.channel.purge(limit=1)
        await ctx.send(f'**:partying_face: {ctx.author.name} hat seine Lobby gemuted.**')

    @commands.command(aliases=['unmuteall', 'UNMUTEALL', 'UnMuteAll', 'Unmuteall', 'unMuteall'])
    @commands.has_guild_permissions(administrator=True)
    async def unMuteAll(self, ctx):
            
        vc = ctx.author.voice.channel
        for member in vc.members:
            await member.edit(mute=False)

        await ctx.channel.purge(limit=1)
        await ctx.send(f'**:partying_face: {ctx.author.name} hat seine Lobby entmuted.**')


def setup(client):
    client.add_cog(BaseOwner(client))