import discord
import time
from discord.ext import commands

class events(commands.Cog):

    def __init__(self, client):
        self.client = client
        self.muteChannel = self.client.get_channel(int: muteChannelID)

    @commands.Cog.listener()
    async def on_ready(self):
        await self.client.change_presence(status=discord.Status.online, activity=discord.Game('Among Us'))

        muteEmbed = discord.Embed(
            title = 'Auto Mute für Among Us   :zipper_mouth:',
            description = 'Reagiere mit :white_check_mark:, um deine Lobby zu muten.',
            colour = discord.Colour.green()
        )

        await self.muteChannel.purge(limit=999)
        muteEmbedMsg = await self.muteChannel.send(embed=muteEmbed)
        muteEmbedObj = await self.muteChannel.fetch_message(muteEmbedMsg.id)
        await muteEmbedObj.add_reaction(str: reactionEmoji)

        print(f"[{str(time.strftime('%d/%m/%Y %H:%M:%S'))}]  {self.client.user} ist online")

    @commands.Cog.listener()
    async def on_command_error(self, ctx, error):
        if isinstance(error, commands.CommandNotFound):
            await ctx.send(f'**:exclamation: Unbekannter Command!**\n        Gebe ``.help`` für Hilfe ein.')

        elif isinstance(error, commands.MissingRequiredArgument):
            await ctx.send(f'**:exclamation: Fülle alle Parameter aus!**\n        Gebe ``.help`` für Hilfe ein.')
        
        else:
            await ctx.send(f'**:exclamation: Unbekannter Error!**\n        Gebe ``.help`` für Hilfe ein.')

    @commands.Cog.listener()
    async def on_reaction_add(self, reaction, user):
        if ((reaction.message.channel.id == int: muteChannelID) & 
            (user.id != int: botID)):

            vc = user.voice.channel
            for member in vc.members:
                await member.edit(mute=True)

    @commands.Cog.listener()
    async def on_reaction_remove(self, reaction, user):
        if ((reaction.message.channel.id == int: muteChannelID) & 
            (user.id != int: botID)):

            vc = user.voice.channel
            for member in vc.members:
                await member.edit(mute=False)
            

def setup(client):
    client.add_cog(events(client))

    